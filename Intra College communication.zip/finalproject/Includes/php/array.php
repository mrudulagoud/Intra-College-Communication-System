<?php

//Nav Menu Link Texts

$nav_menu_texts=array
		("Logged_in"=>array("Home"=>"browse.php","Ask"=>"ask.php","Logout"=>"logout.php"),
		 "Logged_out"=>array("Browse"=>"browse.php","Login"=>"index.php","Sign Up"=>"index.php?sign-up"));
?>