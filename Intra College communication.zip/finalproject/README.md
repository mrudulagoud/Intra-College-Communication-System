# Questania- A Question Answer Website Much Like Quora.

-Backend Development in Core PHP, Front end Development in Bootstrap Framework

-Create a Database named Questania and upload the SQL File. 

-Change DB Username, Password by Navigating to includes/php/connection.php

-Demo Email is: admin@example.com and Password is: questania123

-Enjoy Coding
